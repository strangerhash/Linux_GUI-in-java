// import java.awt.Color;
// import java.awt.*;  
// import java.awt.event.*;  
// import javax.swing.*;  
// public class FirstSwingExample {  
// public static void main(String[] args) {  
// JFrame f=new JFrame();//creating instance of JFrame  
          
// JButton b=new JButton("click");//creating instance of JButton 
// JButton c=new JButton("submit");
// JButton d=new JButton("login");
 
// Label displayLabel=new Label("0",Label.RIGHT); 
// Label memLabel=new Label("0",Label.RIGHT); 
// int tempX=200, y=200;  
// displayLabel.setBounds(tempX,y,240,50);  
// displayLabel.setBackground(Color.green);  
// displayLabel.setForeground(Color.RED);  
// f.add(displayLabel);  
// memLabel.setBounds(100,  200,100, 30);  
// f.add(memLabel); 
// memLabel.setBackground(Color.red);
// String family_name;
// family_name = JOptionPane.showInputDialog("Family Name");
// String full_name;
// if(family_name=="")
// {
// full_name = "You have logged in suuccesfull ";
// //full_name.setForeground(Color.RED);
// JOptionPane.showMessageDialog( null, full_name );
// }
// else

// {
//     full_name = "You are just an error";
//     JOptionPane.showMessageDialog( null, full_name );   
// }
// //b.setBounds(130,100,100, 40);//x axis, y axis, width, height  
// c.setBounds(0,10,100,50); 
// d.setBounds(100,10,100,50);       
// //f.add(b);//adding button in JFrame  
// f.add(c); 
// f.add(d)  ;       
// f.setSize(400,500);//400 width and 500 height  
// f.setLayout(null);//using no layout managers  
// f.setVisible(true);//making the frame visible  
// }  
// }  



// import javax.swing.*;  
// import java.awt.event.*;  
// import java.net.*;  
// public class FirstSwingExample extends JFrame implements ActionListener{  
//     JLabel l;  
//     JTextField tf;  
//     JButton b;  
// FirstSwingExample(){  
//     super("IP Finder Tool - Javatpoint");  
//     l=new JLabel("Enter URL:");  
//     l.setBounds(50,70,150,20);;  
//     tf=new JTextField();  
//     tf.setBounds(50,100,200,20);  
      
//     b=new JButton("Find IP");  
//     b.setBounds(50,150,80,30);  
//     b.addActionListener(this);  
//     add(l);  
//     add(tf);  
//     add(b);  
//     setSize(300,300);  
//     setLayout(null);  
//     setVisible(true);  
// }  
// public void actionPerformed(ActionEvent e){  
//     String url=tf.getText();  
//     try {  
//         InetAddress ia=InetAddress.getByName(url);  
//         String ip=ia.getHostAddress();  
//         JOptionPane.showMessageDialog(this,ip);  
//     } catch (UnknownHostException e1) {  
//         JOptionPane.showMessageDialog(this,e1.toString());  
//     }  
// }  
// public static void main(String[] args) {  
//     new FirstSwingExample();  
// }  
// }

import java.awt.*;  
import java.awt.event.*;  
import java.io.InputStream;  
import java.net.*;  
public class FirstSwingExample extends Frame implements ActionListener{  
    TextField tf;  
    TextArea ta;  
    Button b;  
    Label l;  
    FirstSwingExample(){  
        super("Hack the point:stranger");  
        l=new Label("Enter URL:");  
        l.setBounds(50,50,50,20);  
        l.setBackground(Color.black); 
        l.setForeground(Color.green); 
        tf=new TextField();  
        tf.setBounds(120,50,250,20);  
        tf.setBackground(Color.black); 
        tf.setForeground(Color.green); 
        b=new Button("Find me and server");  
        b.setBounds(120, 100,120,30);  
        b.addActionListener(this);
        b.setBackground(Color.black);  
        b.setForeground(Color.green);  
        ta=new TextArea();  
        ta.setBounds(120,150,600,600);  
        ta.setBackground(Color.black); 
        ta.setForeground(Color.green); 
          
        add(l);add(tf);add(b);add(ta);  
        setSize(800,800);
        setBackground(Color.black);  
        setLayout(null);  
        setVisible(true);  
    }  
    public void actionPerformed(ActionEvent e){  
        String s=tf.getText();  
        if(s==null){}  
        else{  
            try{  
            URL u=new URL(s);  
            URLConnection uc=u.openConnection();  
          
            InputStream is=uc.getInputStream();  
            int i;  
            StringBuilder sb=new StringBuilder();  
            while((i=is.read())!=-1){  
                sb.append((char)i);  
            }  
            String source=sb.toString();  
            ta.setText(source);  
            }catch(Exception ex){System.out.println(e);}  
        }  
    }  
    public static void main(String[] args) {  
        new FirstSwingExample();  
    }  
}  