import javax.lang.model.util.ElementScanner6;
import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;  
import java.net.*;
import java.io.*;  
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
public class IPFinder extends JFrame implements ActionListener{  
    JLabel l;  
    JTextField tf,field;  
    JButton b,c;  
IPFinder(){  
    super("NEW TECHNOLOGY");  
    l=new JLabel("Enter URL:");  
    l.setBounds(50,70,150,20);;  
    tf=new JTextField();  
    tf.setBounds(50,100,200,20);  
    tf.setForeground(Color.green);
    tf.setBackground(Color.black);
      
    b=new JButton("Find IP");  
    b.setBounds(50,150,80,30);  
    b.addActionListener(this); 
    c=new JButton("Find data");  
    c.setBounds(50,200,80,30);
    c.addActionListener(this);  
    add(c);
    add(l);  
    add(tf);  
    add(b);  
    field = new JTextField();
    field.setText("Java Code Geeks");
    field.setBounds(50,300,200,20);  
    field.setForeground(Color.green);
    field.setBackground(Color.black);
    field.setEditable(false);
    add(field);
    setSize(800,800);  
    setLayout(null);  
    setVisible(true);  
}  



public void actionPerformed(ActionEvent e){ 
    if(e.getSource()==b) 
    {
    String url=tf.getText();  
    try {  
        InetAddress ia=InetAddress.getByName(url);  
        String ip=ia.getHostAddress();  
        JOptionPane.showMessageDialog(this,ip);  
        System.out.println(ip);
    } catch (UnknownHostException e1) {  
        JOptionPane.showMessageDialog(this,e1.toString());  
    }
  }
  else
  {
     // System.out.println("hello");
     field.setText("hello");
     new  MenuExample(); 

     //new FileChooser1.choose();
    }
     

}  

public static void main(String[] args) { 
   
    new IPFinder();
    pingme obj= new pingme();
    obj.pingme();
    Program x=new Program();
    x.prin();
    zip a=new zip();
    a.choose();

    //JFileChooser1=new JFileChooser1();

    

  }  
}  
class Program extends IPFinder{  
    int bonus=10000;
    public void prin()
    {
              System.out.println("everything oky");
   }  
}


//import javax.swing.*;  
class MenuExample extends IPFinder implements ActionListener{    
    JFrame f;    
    JMenuBar mb;    
    JMenu file,edit,help;    
    JMenuItem cut,copy,paste,selectAll,save,saveas;    
    JTextArea ta;    
    MenuExample(){    
    f=new JFrame();    
    cut=new JMenuItem("cut");    
    copy=new JMenuItem("copy");    
    paste=new JMenuItem("paste");    
    selectAll=new JMenuItem("selectAll");
    save=new JMenuItem("Save");
    saveas=new JMenuItem("Save As");
    

    cut.addActionListener(this);    
    copy.addActionListener(this);    
    paste.addActionListener(this);    
    selectAll.addActionListener(this);    
    mb=new JMenuBar();    
    file=new JMenu("File");    
    edit=new JMenu("Edit");    
    help=new JMenu("Help");

    edit.add(cut);edit.add(copy);edit.add(paste);edit.add(selectAll); 
    file.add(save);
    file.add(saveas);   
    mb.add(file);mb.add(edit);mb.add(help);    
    ta=new JTextArea();    
    ta.setBounds(5,5,360,320);    
    f.add(mb);f.add(ta);    
    f.setJMenuBar(mb);  
    f.setLayout(null);    
    f.setSize(400,400);    
    f.setVisible(true);    
    }     
    public void actionPerformed(ActionEvent e) {    
    if(e.getSource()==cut)    
    ta.cut();    
    if(e.getSource()==paste)    
    ta.paste();    
    if(e.getSource()==copy)    
    ta.copy();    
    if(e.getSource()==selectAll)    
    ta.selectAll();    
    }    
}