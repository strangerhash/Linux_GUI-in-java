public class Main
{
public static void main(String[] args)
{
    InStack instack=new InStack();
    if(!instack.isFull())
    {
        instack.push(3);
        instack.push(6);
        instack.push(7);
        instack.push(8);

    } 
    System.out.println(instack.pop());
    System.out.println(instack.pop());
}



}