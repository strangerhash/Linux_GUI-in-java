import java.util.*;
import java.io.BufferedReader;
import java.io.InputStreamReader; 
public class duplcate{
            public static void main(String[] args)
            {
              // int i,j,n=0,rev;
              // Scanner in=new Scanner(System.in);
              // System.out.println("Enter number");
              // int x=in.nextInt();
              // int y=x;

              // //System.out.println(x);
              // while(x!=0)
              // {
              //   rev=x%10;
              //   n=rev+n*10;
              //   x=x/10;

              // }

              // //System.out.println(n);
              // if(n==y)
              // {
              //   System.out.println("equal");
              // }
              // else
              // {
              //   System.out.println("equal not");
              // }4

              String strValue="sdfsdfdskdf@13@9gdfn1243434sdfsdgdbdnytnrt";
              String str = strValue.trim();
              String digits="";
              for (int i = 0; i < str.length(); i++) {
                  char chrs = str.charAt(i);              
                  if (Character.isDigit(chrs))
                      digits = digits+chrs;
              }
              System.out.print(digits);
          }



            } 
          

//}
        