// public class hello {
//     int puppyAge;
 
//     public hello(String name) {
//        // This constructor has one parameter, name.
//        System.out.println("Name chosen is :" + name );
//     }
 
//     public void setAge( int age ) {
//        puppyAge = age;
//     }
 
//     public int getAge( ) {
//        System.out.println("Puppy's age is :" + puppyAge );
//        return puppyAge;
//     }
 
//     public static void main(String []args) {
//        /* Object creation */
//        hello myPuppy = new hello( "tommy" );
 
//        /* Call class method to set puppy's age */
//        myPuppy.setAge( 2 );
 
//        /* Call another class method to get puppy's age */
//        myPuppy.getAge();
 
//        /* You can access instance variable as follows as well */
//        System.out.println("Variable Value :" + myPuppy.puppyAge );
//     }
//  }

// import java.util.Scanner;
// class Input {
//     public static void main(String[] args) {
    	
//     	Scanner input = new Scanner(System.in);
    	
//     	// Getting float input
//     	System.out.print("Enter float: ");
//     	float myFloat = input.nextFloat();
//     	System.out.println("Float entered = " + myFloat);
    	
//     	// Getting double input
//     	System.out.print("Enter double: ");
//     	double myDouble = input.nextDouble();
//     	System.out.println("Double entered = " + myDouble);
    	
//     	// Getting String input
//     	System.out.print("Enter text: ");
//     	String myString = input.next();
//     	System.out.println("Text entered = " + myString);
//     }
// }
// public class hello{    
//    public static void main(String args[])
//    {    
//      int num=30,i;
//      for(i=2;i<num;i++)
//      {
//         if(num%i==0)
//         {
//            System.out.println("Prime");
//            break;
//         }
//         else
//         {
//          System.out.println(" Not Prime");
//         }

//      }

  
//    }   
// }


// public class hello
// {
//   public static void main(String args[])
//   {
//      int a=5;
//      System.out.println(a++);
//      System.out.println(++a);

//   }
// }
// class hello {
   
//    // Constructor method
  
//    hello() {
//      System.out.println("Constructor method is called when an object of it's class is created");
//    }
  
//    // Main method where program execution begins
  
//    public static void main(String[] args) {
//      staticMethod();
//      //hello object = new hello();
//      //object.nonStaticMethod();
//    }
  
//    // Static method
  
//    static void staticMethod() {
//      System.out.println("Static method can be called without creating object");
//    }
  
//    // Non static method
  
//    void nonStaticMethod() {
//      System.out.println("Non static method must be called by creating an object");
//    }
//  }
 

// import java.util.*;  
// public class hello{  
// public static void main(String args[]){  
// Stack<String> stack = new Stack<String>();  
// stack.push("Ayush");  
// stack.push("Garvit");  
// stack.push("Amit");  
// stack.push("Ashish");  
// stack.push("Garima");  
// stack.pop();  
// Iterator<String> itr=stack.iterator();  
// while(itr.hasNext()){  
// System.out.println(itr.next());  
// }  
// }  
// }  

//Priority que
// import java.util.*;  
// public class hello{  
// public static void main(String args[]){  
// PriorityQueue<String> queue=new PriorityQueue<String>();  
// queue.add("8");
// queue.add("5");  
// queue.add("4");  
// queue.add("3");  
// queue.add("2");  
// queue.add("1");
// //queue.add("0");
// System.out.println("head:"+queue.element());  
// System.out.println("head:"+queue.peek());  
// System.out.println("iterating the queue elements:");  
// Iterator itr=queue.iterator();  
// while(itr.hasNext()){  
// System.out.println(itr.next());  
// }  
// queue.remove();  
// queue.poll();  
// System.out.println("after removing two elements:");  
// Iterator<String> itr2=queue.iterator();  
// while(itr2.hasNext()){  
// System.out.println(itr2.next());  
// }  
// }  
// }  


// Java code to illustrate poll() 
// import java.util.*; 

// public class hello{ 
// 	public static void main(String args[]) 
// 	{ 
// 		// Creating an empty PriorityQueue 
// 		PriorityQueue<String> queue = new PriorityQueue<String>(); 

// 		// Use add() method to add elements into the Queue 
// 		queue.add("Welcome"); 
// 		queue.add("To"); 
// 		queue.add("Geeks"); 
// 		queue.add("For"); 
// 		queue.add("Geeks"); 

// 		// Displaying the PriorityQueue 
// 		System.out.println("Initial PriorityQueue: " + queue); 

// 		// Fetching and removing the element at the head of the queue 
// 		System.out.println("The element at the head of the"
// 						+ " queue is: " + queue.poll()); 

// 		// Displaying the Queue after the Operation 
// 		System.out.println("Final PriorityQueue: " + queue); 
// 	} 
// } 


//Array list

// import java.util.*;  
// class hello
// {  
// public static void main(String args[]){  
// ArrayList<String> list=new ArrayList<String>();//Creating arraylist  
// list.add("6");//Adding object in arraylist  
// list.add("Vijay");  
// list.add("Ravi");  
// list.add("Ajay");  
// //Traversing list through Iterator  
// Iterator itr=list.iterator();  
// while(itr.hasNext()){  
// System.out.println(itr.next());  
// }  
// }  
// }

// //linked list
// import java.util.*;  
// public class hello{  
// public static void main(String args[]){  
// LinkedList<String> al=new LinkedList<String>();  
// al.add("Ravi");  
// al.add("Vijay");  
// al.add("Ravi");  
// al.add("Ajay");  
// //al.remove("Ajay");
// Iterator<String> itr=al.iterator();  
// while(itr.hasNext()){  
// System.out.println(itr.next());  
// }  
// al.remove("Ajay");
// while(itr.hasNext()){  
//    System.out.println(itr.next());  
//    }  

// }  
// }  

// import java.util.*;  
// import java.io.*;  
// public class hello {  
// public static void main(String[] args)throws Exception{  
  
// Properties p=System.getProperties();  
// Set set=p.entrySet();  
  
// Iterator itr=set.iterator();  
// while(itr.hasNext()){  
// Map.Entry entry=(Map.Entry)itr.next();  
// System.out.println(entry.getKey()+" = "+entry.getValue());  
// }  
  
// }  
// }



// import java.util.*;  
// public class hello{  
// public static void main(String args[]){  
// //Creating HashSet and adding elements  
// HashSet<String> set=new HashSet<String>();  
// set.add("Ravi");  
// set.add("Vijay");  
// set.add("Ravi");  
// set.add("Ajay");  
// //Traversing elements  
// Iterator<String> itr=set.iterator();  
// while(itr.hasNext()){  
// System.out.println(itr.next());  
// }  
// }  
// }  

 
// public class  hello{  
//     public static void main(String args[]){  
//     String s1="java";//creating string by java string literal  
//     char ch[]={'s','t','r','i','n','g','s'};  
//     String s2=new String(ch);//converting char array to string  
//     String s3=new String("example");//creating java string by new keyword  
//     System.out.println(s1);  
//     System.out.println(s2);  
//     System.out.println(s3);  
//     }}  



// import java.util.regex.*;  
// public class hello{  
// public static void main(String args[]){  
// //1st way  
// Pattern p = Pattern.compile(".s");//. represents single character  
// Matcher m = p.matcher("as");  
// boolean b = m.matches();  
  
// //2nd way  
// boolean b2=Pattern.compile(".s").matcher("as").matches();  
  
// //3rd way   
// System.out.println(b+" "+b2+" "+b3);  
// }}  


// import java.util.regex.*;  
// class hello{  
// public static void main(String args[]){  
// System.out.println(Pattern.matches("..s", "as"));//true (2nd char is s)  
// System.out.println(Pattern.matches(".s", "mk"));//false (2nd char is not s)  
// System.out.println(Pattern.matches(".s", "mst"));//false (has more than 2 char)  
// System.out.println(Pattern.matches(".s", "amms"));//false (has more than 2 char)  
// System.out.println(Pattern.matches("..s", "mas"));//true (3rd char is s)  
// }
// }  


// class hello{  
//     public static void main(String args[]){  
//      System.out.println("Hello sattu");  
//      //hello();
     
//     }  
// }

//hello();

class hello {
    public static void main(String[] args) {
        System.out.println("About to encounter a method.");
        // method call
        myMethod();
        System.out.println("Method was executed successfully!");
    }
    // method definition
     public static void  myMethod(){
        System.out.println("Printing from inside myMethod()!");
    }
 }
