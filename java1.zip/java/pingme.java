import java.io.BufferedReader;
import java.io.InputStreamReader;
import javax.swing.*;
import java.awt.Color;
import java.awt.event.*;  
import java.net.*;
import java.io.*;  
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
class pingme
{

    public void pingme()
    {   System.out.println("java");

    }
} 