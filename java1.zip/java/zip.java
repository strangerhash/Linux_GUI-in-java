//package demo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
import javax.swing.JFileChooser;
import javax.swing.filechooser.FileSystemView;

// public class zip{

//     public static void main(String args[]) {
//         FileChooser1 y=new FileChooser1 ();
//          y.choose();

//         try {
//             // let's create a ZIP file to write data
//             FileOutputStream fos = new FileOutputStream("sample.zip");
//             ZipOutputStream zipOS = new ZipOutputStream(fos);

//             String file1 = "names.txt";
//             String file2 = "java7.txt";
//             String file3 = "targetrr/apache.txt";
//             String file4 = "java.txt";

//             writeToZipFile(file1, zipOS);
//             writeToZipFile(file2, zipOS);
//             writeToZipFile(file3, zipOS);
//             writeToZipFile(file4, zipOS);

//             zipOS.close();
//             fos.close();

//         } catch (FileNotFoundException e) {
//             e.printStackTrace();
//         } catch (IOException e) {
//             e.printStackTrace();
//         }

//     }

//     /**
//      * Add a file into Zip archive in Java.
//      * 
//      * @param fileName
//      * @param zos
//      * @throws FileNotFoundException
//      * @throws IOException
//      */
//     public static void writeToZipFile(String path, ZipOutputStream zipStream)
//             throws FileNotFoundException, IOException {

//         System.out.println("Writing file : '" + path + "' to zip file");

//         File aFile = new File(path);
//         FileInputStream fis = new FileInputStream(aFile);
//         ZipEntry zipEntry = new ZipEntry(path);
//         zipStream.putNextEntry(zipEntry);

//         byte[] bytes = new byte[1024];
//         int length;
//         while ((length = fis.read(bytes)) >= 0) {
//             zipStream.write(bytes, 0, length);
//         }

//         zipStream.closeEntry();
//         fis.close();
//     }
// }


class zip{

	public void choose() {

		JFileChooser jfc = new JFileChooser(FileSystemView.getFileSystemView().getHomeDirectory());

		int returnValue = jfc.showOpenDialog(null);
		// int returnValue = jfc.showSaveDialog(null);

		if (returnValue == JFileChooser.APPROVE_OPTION) {
			File selectedFile = jfc.getSelectedFile();
			System.out.println(selectedFile.getAbsolutePath());
		}

	}

}

